
#include <list>
#include <cstdlib>
#include <string>

using namespace std;


list<string> bubbleSort(list<string>& input);

list<string> mergeSort(list<string>& input);

list<string>& quickSort(list<string>& input);

list<string> heapSort(list<string>& input);

list<string> sysSort(list<string>& input);
